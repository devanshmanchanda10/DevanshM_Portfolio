import React, { useState, useEffect } from 'react';
import { 
  Briefcase, 
  GraduationCap, 
  Mail, 
  Linkedin, 
  Phone, 
  MapPin, 
  ExternalLink, 
  ChevronRight, 
  BarChart2, 
  Users, 
  Zap,
  Download,
  Database,
  Search,
  Layout,
  MousePointer2
} from 'lucide-react';

const Portfolio = () => {
  const [activeSection, setActiveSection] = useState('home');
  const [isScrolled, setIsScrolled] = useState(false);

  // Handle scroll effects
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
      
      const sections = ['home', 'experience', 'projects', 'skills', 'education'];
      const current = sections.find(section => {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          return rect.top >= 0 && rect.top <= 300;
        }
        return false;
      });
      if (current) setActiveSection(current);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setActiveSection(id);
    }
  };

  const NavLink = ({ id, label }) => (
    <button
      onClick={() => scrollToSection(id)}
      className={`text-sm font-medium transition-all duration-300 relative px-2 ${
        activeSection === id 
          ? 'text-blue-600' 
          : 'text-slate-600 hover:text-blue-500'
      }`}
    >
      {label}
      {activeSection === id && (
        <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-blue-600 rounded-full animate-fade-in" />
      )}
    </button>
  );

  return (
    <div className="min-h-screen font-sans text-slate-800 selection:bg-indigo-100 selection:text-indigo-900 relative overflow-hidden">
      <h1 className="text-3xl font-bold text-center mt-40">Portfolio Placeholder</h1>
    </div>
  );
};

export default Portfolio;